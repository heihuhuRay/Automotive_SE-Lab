void PIT_Init(void);
void PIT_ConfigureTimer(int, unsigned int);
void PIT_StartTimer(int);
void PIT_StopTimer(int);
